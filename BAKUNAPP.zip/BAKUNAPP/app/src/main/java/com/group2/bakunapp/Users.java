package com.group2.bakunapp;

public class Users {
    public String lastname,firstname,middlename,suffix,age,
            sex,address,contactno,email,password,
            category,selectedid,idnumber,civilstatus,pregnancy,
            menstrual,drugallergy,foodallergy,insectallergy,laxerrubberallergy,
            moldallergy,petalalleregy,pollenallergy,comorbidities,hypertension,
            heartdisease,kidneydisease,diabetesmellitus,broncialasthma,immunodeficiency,
            cancer,other,approve,date,appointment,birthdate;

    public Users(){

    }

    public Users(String lastname, String firstname, String middlename, String suffix, String age, String sex, String address, String contactno, String email, String password, String category, String selectedid, String idnumber, String civilstatus, String pregnancy, String menstrual, String drugallergy, String foodallergy, String insectallergy, String laxerrubberallergy, String moldallergy, String petalalleregy, String pollenallergy, String comorbidities, String hypertension, String heartdisease, String kidneydisease, String diabetesmellitus, String broncialasthma, String immunodeficiency, String cancer, String other,String approve, String date,String appointment, String birthdate) {
        this.lastname = lastname;
        this.firstname = firstname;
        this.middlename = middlename;
        this.suffix = suffix;
        this.age = age;
        this.sex = sex;
        this.address = address;
        this.contactno = contactno;
        this.email = email;
        this.password = password;
        this.category = category;
        this.selectedid = selectedid;
        this.idnumber = idnumber;
        this.civilstatus = civilstatus;
        this.pregnancy = pregnancy;
        this.menstrual = menstrual;
        this.drugallergy = drugallergy;
        this.foodallergy = foodallergy;
        this.insectallergy = insectallergy;
        this.laxerrubberallergy = laxerrubberallergy;
        this.moldallergy = moldallergy;
        this.petalalleregy = petalalleregy;
        this.pollenallergy = pollenallergy;
        this.comorbidities = comorbidities;
        this.hypertension = hypertension;
        this.heartdisease = heartdisease;
        this.kidneydisease = kidneydisease;
        this.diabetesmellitus = diabetesmellitus;
        this.broncialasthma = broncialasthma;
        this.immunodeficiency = immunodeficiency;
        this.cancer = cancer;
        this.other = other;
        this.approve = approve;
        this.date = date;
        this.appointment= appointment;
        this.birthdate = birthdate;
    }


}
