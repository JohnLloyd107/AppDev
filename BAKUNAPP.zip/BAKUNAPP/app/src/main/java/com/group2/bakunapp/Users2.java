package com.group2.bakunapp;

public class Users2 {
    private String appoint;

    public Users2() {

    }

    public Users2(String appoint) {
        this.appoint = appoint;

    }
}
