package com.group2.bakunapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class Register extends AppCompatActivity {

    private EditText lastname_input,firstname_input,middlename_input,suffix_input,age_input,sex_input,address_input,contact_no_input,email_input,password_input,idno_input,civil_input;
    private EditText pregnancy_input,menstrual_input,drugallergy_input,foodallergy_input,insect_input,luxerrubber_input,mold_input,petal_input,pollen_input,comorbidities_input;
    private EditText hyper_input,heart_input,kidney_input,diabes_input,broncial_input,immuno_input,cancer_input,other_input, birthdate_input;
    private TextView categ_input,approve_input,date_input;


    private Button sbtbtn;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private Spinner selected_id_input;
    private String selectedid;



    private FirebaseAuth mAuth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();







        lastname_input = (EditText) findViewById(R.id.lastname_input);
        firstname_input = (EditText) findViewById(R.id.firstname_input);
        middlename_input = (EditText) findViewById(R.id.middlename_input);
        suffix_input = (EditText) findViewById(R.id.suffix_input);
        birthdate_input = (EditText) findViewById(R.id.birthdate_input);
        age_input = (EditText) findViewById(R.id.age_input);
        sex_input = (EditText) findViewById(R.id.sex_input);
        address_input = (EditText) findViewById(R.id.address_input);
        contact_no_input = (EditText) findViewById(R.id.contactno_input);

        categ_input = (TextView) findViewById(R.id.category_input);
        selected_id_input= (Spinner) findViewById(R.id.selectedid_input);
        idno_input = (EditText) findViewById(R.id.idnumber_input);
        civil_input = (EditText) findViewById(R.id.civilstatus_input);
        pregnancy_input = (EditText) findViewById(R.id.pregnancy_input);
        menstrual_input = (EditText) findViewById(R.id.menstrual_input);
        drugallergy_input = (EditText) findViewById(R.id.drugallergy_input);
        foodallergy_input = (EditText) findViewById(R.id.foodallergy_input);
        insect_input = (EditText) findViewById(R.id.insectallergy_input);
        luxerrubber_input = (EditText) findViewById(R.id.laxerrubberallergy_input);
        mold_input = (EditText) findViewById(R.id.moldallergy_input);
        petal_input = (EditText) findViewById(R.id.petallergy_input);
        pollen_input= (EditText) findViewById(R.id.pollenallergy_input);
        comorbidities_input = (EditText) findViewById(R.id.comorbidities_input);
        hyper_input = (EditText) findViewById(R.id.hypertension_input);
        heart_input = (EditText) findViewById(R.id.heartdisease_input);
        kidney_input = (EditText) findViewById(R.id.kidneydisease_input);
        diabes_input = (EditText) findViewById(R.id.diabetesmellitus_input);
        broncial_input = (EditText) findViewById(R.id.broncialasthma_input);
        immuno_input = (EditText) findViewById(R.id.immunodeficiency_input);
        cancer_input = (EditText) findViewById(R.id.cancer_input);
        other_input = (EditText) findViewById(R.id.otherdisease_input);
        approve_input = (TextView) findViewById(R.id.appr);
        date_input = (TextView) findViewById(R.id.date);

        sbtbtn = (Button) findViewById(R.id.submitbtn);

        Bundle bundle = getIntent().getExtras();

        String category = bundle.getString("category");

        categ_input.setText(category);

        String lastnames = bundle.getString("lastname");
        String firstnames = bundle.getString("firstname");
        String middlenames = bundle.getString("middlename");
        String suffixs = bundle.getString("suffix");

        lastname_input.setText(lastnames);
        firstname_input.setText(firstnames);
        middlename_input.setText(middlenames);
        suffix_input.setText(suffixs);



        AlertDialog.Builder alert = new AlertDialog.Builder(Register.this);

        List<String> ID = new ArrayList<>();
        ID.add(0,"Please select ID...");
        ID.add("School ID");
        ID.add("Philhealth ID");
        ID.add("Driver License ID");
        ID.add("Postal ID");
        ID.add("Voter's ID");
        ID.add("Senior Citizen ID");

        ArrayAdapter<String> myAdapter;
        myAdapter = new ArrayAdapter<>(Register.this, android.R.layout.simple_spinner_item,ID);

        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        selected_id_input.setAdapter(myAdapter);

        selected_id_input.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getItemAtPosition(position).equals("Select ID")){

                }
                else {
                    selectedid = parent.getItemAtPosition(position).toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });








        sbtbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String lastname = lastname_input.getText().toString().trim();
                String firstname = firstname_input.getText().toString().trim();
                String middlename = middlename_input.getText().toString().trim();
                String suffix = suffix_input.getText().toString().trim();

                String age = age_input.getText().toString().trim();
                String sex = sex_input.getText().toString().trim();
                String address = address_input.getText().toString().trim();
                String contactno= contact_no_input.getText().toString().trim();
                String email = null,password= null,appointment= null;

                String category = categ_input.getText().toString().trim();

                String idnumber = idno_input.getText().toString().trim();
                String civilstatus = civil_input.getText().toString().trim();
                String pregnancy = pregnancy_input.getText().toString().trim();
                String menstrual = menstrual_input.getText().toString().trim();
                String drugallergy = drugallergy_input.getText().toString().trim();
                String foodallergy = foodallergy_input.getText().toString().trim();
                String insectallergy = insect_input.getText().toString().trim();
                String laxerrubberallergy = luxerrubber_input.getText().toString().trim();
                String moldallergy = mold_input.getText().toString().trim();
                String petalalleregy = petal_input.getText().toString().trim();
                String pollenallergy = pollen_input.getText().toString().trim();
                String comorbidities = comorbidities_input.getText().toString().trim();
                String hypertension = hyper_input.getText().toString().trim();
                String heartdisease = heart_input.getText().toString().trim();
                String kidneydisease = heart_input.getText().toString().trim();
                String diabetesmellitus = heart_input.getText().toString().trim();
                String broncialasthma = heart_input.getText().toString().trim();
                String immunodeficiency = heart_input.getText().toString().trim();
                String cancer = heart_input.getText().toString().trim();
                String other = heart_input.getText().toString().trim();
                String approve = approve_input.getText().toString().trim();
                String date = date_input.getText().toString().trim();
                String birthdate = birthdate_input.getText().toString().trim();

                if (lastname.isEmpty()){
                    lastname_input.setError("LastName is required!");
                    lastname_input.requestFocus();
                    return;
                }

                if (firstname.isEmpty()){
                    firstname_input.setError("FirstName is required!");
                    firstname_input.requestFocus();
                    return;
                }

                if (middlename.isEmpty()){
                    middlename_input.setError("MiddleName is required!");
                    middlename_input.requestFocus();
                    return;
                }

                if (selectedid.isEmpty()){
                    Toast.makeText(Register.this, "Please select ID", Toast.LENGTH_SHORT).show();
                    selected_id_input.requestFocus();
                    return;
                }

                if (birthdate.isEmpty()){
                    birthdate_input.setError("Birthdate is required!");
                    birthdate_input.requestFocus();
                    return;
                }



                if (age.isEmpty()){
                    age_input.setError("Age is required!");
                    age_input.requestFocus();
                    return;
                }

                if (sex.isEmpty()){
                    sex_input.setError("Sex is required!");
                    sex_input.requestFocus();
                    return;
                }



                if (address.isEmpty()){
                    address_input.setError("Address is required!");
                    address_input.requestFocus();
                    return;
                }

                if (contactno.isEmpty()){
                    contact_no_input.setError("Contact No. is required!");
                    contact_no_input.requestFocus();
                    return;
                }



                if (category.isEmpty()){
                    categ_input.setError("Category is required!");
                    categ_input.requestFocus();
                    return;
                }



                if (idnumber.isEmpty()){
                    idno_input.setError("ID No. is required!");
                    idno_input.requestFocus();
                    return;
                }

                if (civilstatus.isEmpty()){
                    civil_input.setError("Civil Status is required!");
                    civil_input.requestFocus();
                    return;
                }

                if (pregnancy.isEmpty()){
                    pregnancy_input.setError("Pregnancy is required!");
                    pregnancy_input.requestFocus();
                    return;
                }

                if (menstrual.isEmpty()){
                    menstrual_input.setError("Menstrual is required!");
                    menstrual_input.requestFocus();
                    return;
                }

                if (drugallergy.isEmpty()){
                    drugallergy_input.setError("Drug Allergy required!");
                    drugallergy_input.requestFocus();
                    return;
                }

                if (foodallergy.isEmpty()){
                    foodallergy_input.setError("Food Allergy is required!");
                    foodallergy_input.requestFocus();
                    return;
                }

                if (insectallergy.isEmpty()){
                    insect_input.setError("Insect Allergy is required!");
                    insect_input.requestFocus();
                    return;
                }

                if (laxerrubberallergy.isEmpty()){
                    luxerrubber_input.setError("Laxer/Rubber Allergy is required!");
                    luxerrubber_input.requestFocus();
                    return;
                }

                if (moldallergy.isEmpty()){
                    mold_input.setError("Mold Allergy is required!");
                    mold_input.requestFocus();
                    return;
                }

                if (petalalleregy.isEmpty()){
                    petal_input.setError("Petal Allergy is required!");
                    petal_input.requestFocus();
                    return;
                }

                if (pollenallergy.isEmpty()){
                    pollen_input.setError("Pollen Allergy is required!");
                    pollen_input.requestFocus();
                    return;
                }

                if (comorbidities.isEmpty()){
                    comorbidities_input.setError("Comorbidities is required!");
                    comorbidities_input.requestFocus();
                    return;
                }

                if (hypertension.isEmpty()){
                    hyper_input.setError("Hypertension is required!");
                    hyper_input.requestFocus();
                    return;
                }

                if (heartdisease.isEmpty()){
                    heart_input.setError("Heart Disease is required!");
                    heart_input.requestFocus();
                    return;
                }

                if (kidneydisease.isEmpty()){
                    kidney_input.setError("Kidney Disease is required!");
                    kidney_input.requestFocus();
                    return;
                }

                if (diabetesmellitus.isEmpty()){
                    diabes_input.setError("Diabetesmellitus is required!");
                    diabes_input.requestFocus();
                    return;
                }

                if (broncialasthma.isEmpty()){
                    broncial_input.setError("Broncial Asthma is required!");
                    broncial_input.requestFocus();
                    return;
                }

                if (immunodeficiency.isEmpty()){
                    immuno_input.setError("Immunodeficiency is required!");
                    immuno_input.requestFocus();
                    return;
                }

                if (cancer.isEmpty()){
                    cancer_input.setError("Cancer is required!");
                    cancer_input.requestFocus();
                    return;
                }

                if (other.isEmpty()){
                    other_input.setError("Insect Allergy is required!");
                    other_input.requestFocus();
                    return;
                }


                alert.setTitle("Alert!!");
                alert.setMessage("Are you sure you want to Submit?");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {






                                            Users user = new Users(lastname,firstname,middlename,suffix,age,
                                                    sex,address,contactno,email,password,
                                                    category,selectedid,idnumber,civilstatus,pregnancy,
                                                    menstrual,drugallergy,foodallergy,insectallergy,laxerrubberallergy,
                                                    moldallergy,petalalleregy,pollenallergy,comorbidities,hypertension,
                                                    heartdisease,kidneydisease,diabetesmellitus,broncialasthma,immunodeficiency,
                                                    cancer,other,approve,date,appointment,birthdate);

                                            FirebaseDatabase.getInstance().getReference(Users.class.getSimpleName())
                                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {

                                                    if (task.isSuccessful()){


                                                        Toast.makeText(Register.this, "Successfully Submit", Toast.LENGTH_LONG).show();
                                                        startActivity(new Intent(Register.this,Appointment.class));
                                                        finish();

                                                    }
                                                }
                                            });





                    }
                });
                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        return;
                    }
                });

                alert.create().show();
















            }
        });













    }

    @Override
    public void onBackPressed(){

        AlertDialog.Builder alert = new AlertDialog.Builder(Register.this);
        alert.setTitle("Discard");
        alert.setMessage("Are you sure you want to Exit?");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Bundle bundle = getIntent().getExtras();

                String lastnames = bundle.getString("lastname");
                String firstnames = bundle.getString("firstname");
                String middlenames = bundle.getString("middlename");
                String suffixs = bundle.getString("suffix");





                Intent nextact = new Intent(Register.this, Category.class);
                nextact.putExtra("lastname",lastnames);
                nextact.putExtra("firstname",firstnames);
                nextact.putExtra("middlename",middlenames);
                nextact.putExtra("suffix",suffixs);



                startActivity(nextact);
                finish();
            }
        });

        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });
        alert.create().show();



    }


}